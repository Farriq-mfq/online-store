<?php 

    namespace App\Interface;
    interface AuthInterface{
        function getFieldData();
    }